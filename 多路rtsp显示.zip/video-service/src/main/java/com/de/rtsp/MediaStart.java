package com.de.rtsp;

import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import javax.validation.constraints.NotEmpty;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicInteger;

/**
 *  
 *  * @projectName videoservice
 *  * @title     MadiaStart   
 *  * @package    com.de.rtsp  
 *  * @description    程序启动时加载一次，rtspj解析传输到websocket启动类 
 *  * @author IT_CREAT     
 *  * @date  2020 2020/4/18 0018 下午 22:48  
 *  * @version V1.0.0 
 *  
 */
@Component
public class MediaStart {

    private static final int CORE_THREAD_SIZE = 6;

    public static ThreadPoolExecutor pullStreamThreadPool;

    public static ThreadPoolExecutor sendStreamThreadPool;

    public static List<String> linkIds = new ArrayList<>();

    @PostConstruct
    public void init() {
        // 拉流线程池
        pullStreamThreadPool = new ThreadPoolExecutor(CORE_THREAD_SIZE,
                CORE_THREAD_SIZE,
                0,
                TimeUnit.MILLISECONDS,
                new LinkedBlockingDeque<>(),
                new ThreadFactoryLocal("Thread_pullStream_%s"));

        // 推流线程池
        sendStreamThreadPool = new ThreadPoolExecutor(CORE_THREAD_SIZE,
                CORE_THREAD_SIZE,
                0,
                TimeUnit.MILLISECONDS,
                new LinkedBlockingDeque<>(),
                new ThreadFactoryLocal("Thread_pullStream_%s"));
    }

    // 添加每条链路的线程任务
    public static void addLinkThreadPool(String linkId){
        if(linkIds.contains(linkId)){
            return;
        }
        // 拉流线程任务
        MediaTransfer mediaTransfer = new MediaTransfer()
                .setLinkId(linkId);
        pullStreamThreadPool.execute(new Runnable() {
            @Override
            public void run() {
                mediaTransfer.live();
            }
        });

        // 推流线程任务
        sendStreamThreadPool.execute(new Runnable() {
            @Override
            public void run() {
                mediaTransfer.sendRtspInfo();
            }
        });

        linkIds.add(linkId);
    }

    public static class ThreadFactoryLocal implements ThreadFactory {
        private final AtomicInteger poolNumber = new AtomicInteger(1);
        private final ThreadGroup group;
        private final AtomicInteger threadNumber = new AtomicInteger(1);
        private final String namePrefix;

        public ThreadFactoryLocal(@NotEmpty String namePrefix) {
            SecurityManager s = System.getSecurityManager();
            this.group = (s != null) ? s.getThreadGroup() :
                    Thread.currentThread().getThreadGroup();
            this.namePrefix = namePrefix;
        }

        @Override
        public Thread newThread(Runnable r) {
            Thread t = new Thread(group, r, namePrefix.replace("%s", String.valueOf(threadNumber.getAndIncrement()))
                    , 0);
            if (t.isDaemon()) {
                t.setDaemon(false);
            }
            if (t.getPriority() != Thread.NORM_PRIORITY) {
                t.setPriority(Thread.NORM_PRIORITY);
            }
            return t;
        }
    }

}
