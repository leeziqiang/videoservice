package com.de.rtsp;

import cn.hutool.core.codec.Base64;
import com.de.entity.SendRstpInfo;
import com.de.service.WebSocketServer;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import lombok.extern.slf4j.Slf4j;
import org.bytedeco.javacv.FFmpegFrameGrabber;
import org.bytedeco.javacv.Frame;
import org.bytedeco.javacv.FrameGrabber;
import org.bytedeco.javacv.Java2DFrameConverter;

import javax.imageio.ImageIO;
import java.awt.image.BufferedImage;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.util.concurrent.LinkedBlockingDeque;
import java.util.concurrent.TimeUnit;

/**
 *  
 *  * @projectName videoservice
 *  * @title     MediaUtils   
 *  * @package    com.de.rtsp  
 *  * @description   获取rtsp流，解析为视频帧，websocket传递到前台显示 
 *  * @author IT_CREAT     
 *  * @date  2020 2020/4/12 0012 下午 18:24  
 *  * @version V1.0.0 
 *  
 */
@Slf4j
@Data
@NoArgsConstructor
@Accessors(chain = true)
public class MediaTransfer {
    public static String rtspTransportType = "udp";
    /**
     * 视频帧率（更改可实现视频的倍速播放效果）
     */
    public static int frameRate = 30;
    /**
     * 视频宽度（更改可实现视频的清晰度）
     */
    public static int frameWidth = 960;
    /**
     * 视频高度（更改可实现视频的清晰度）
     */
    public static int frameHeight = 540;

    private String linkId;

    /**
     * 开启获取rtsp流，解析rtsp流，装入队列
     */
    public void live() {
        log.info("启动rtsp拉流服务成功(链路)：" + linkId);
        Java2DFrameConverter java2DFrameConverter = new Java2DFrameConverter();
        while (true) {
            try { // 此处抓异常，因为fFmpegFrameGrabberCaches集合可能在循环阶段加入新的FFmpegFrameGrabberCache对象，
                // 导致位置不对，抛出异常，所以这里要抓
                MediaConstant.FFmpegFrameGrabberCache fFmpegFrameGrabberCache = MediaConstant.getFFmpegFrameGrabberCache(linkId);
                if (fFmpegFrameGrabberCache == null) {
                    continue;
                }
                FFmpegFrameGrabber grabber = fFmpegFrameGrabberCache.getGrabber();
                String linkId = fFmpegFrameGrabberCache.getLinkId();
                // grabber等于空则需要创建解析对象
                if (grabber == null) {
                    String rtspUrl = fFmpegFrameGrabberCache.getRtspPath();
                    log.info("【" + linkId + "】连接rtsp：" + rtspUrl + ",开始创建grabber");
                    grabber = createGrabber(linkId, rtspUrl);
                    fFmpegFrameGrabberCache.setGrabber(grabber);
                    if (grabber != null) {
                        log.info("【" + linkId + "】创建" + rtspUrl + ": grabber成功");
                    } else {
                        log.warn("【" + linkId + "】创建" + rtspUrl + ": grabber失败");
                    }
                }
                SendRstpInfo sendRstpInfo = startCameraPush(fFmpegFrameGrabberCache, java2DFrameConverter);
                // 将所有的rtsp拉流数据装入集合中
                try {
                    if (sendRstpInfo != null) {
                        // 将解析好的数据装入队列中
                        if (!MediaConstant.linkedBlockingDequeConcurrentHashMap.containsKey(linkId)) {
                            MediaConstant.linkedBlockingDequeConcurrentHashMap.put(linkId, new LinkedBlockingDeque<>());
                        }
                        LinkedBlockingDeque<SendRstpInfo> linkedBlockingDeque = MediaConstant.linkedBlockingDequeConcurrentHashMap.get(linkId);
                        boolean offer = linkedBlockingDeque.offer(sendRstpInfo, 50, TimeUnit.MILLISECONDS);
                        if (!offer) {
                            log.warn("本轮解析视频数据帧集合数据放入队列失败。。。");
                        }
                    }
                } catch (InterruptedException e) {
                    log.error("解析视频数据帧集合数据放入队列失败异常");
                    log.error("linkedBlockingDeque exception : ", e);
                }
            } catch (RuntimeException e) {
                log.error("RuntimeException exception : ", e);
            }
        }
    }

    /**
     * 构造视频抓取器
     *
     * @param rtsp 拉流地址
     * @return
     */
    public FFmpegFrameGrabber createGrabber(String linkId, String rtsp) {
        // 获取视频源
        try {
            FFmpegFrameGrabber grabber = FFmpegFrameGrabber.createDefault(rtsp);
            grabber.setOption("rtsp_transport", rtspTransportType);
            // 设置采集器构造超时时间(单位微秒，1秒=1000000微秒) ，避免在start处阻塞
            grabber.setOption("stimeout", "2000000");
            //设置帧率
            grabber.setFrameRate(frameRate);
            //设置获取的视频宽度
            grabber.setImageWidth(frameWidth);
            //设置获取的视频高度
            grabber.setImageHeight(frameHeight);
            //设置视频bit率
            grabber.setVideoBitrate(2000000);
            return grabber;
        } catch (FrameGrabber.Exception e) {
            log.error("【" + linkId + "】创建解析rtsp FFmpegFrameGrabber 失败");
            log.error("【" + linkId + "】create rtsp FFmpegFrameGrabber exception: ", e);
            return null;
        }
    }

    /**
     * 推送图片（摄像机直播）
     */
    public SendRstpInfo startCameraPush(MediaConstant.FFmpegFrameGrabberCache fFmpegFrameGrabberCache, Java2DFrameConverter java2DFrameConverter) {
        // 因为前端请求更改数据，grabber有可能在执行过程中被置空，所以在下面会抓取运行时异常，从而解决这个问题，
        // 为什么不同步，因为没必要，更改地址其实相当于重新开始拉取新的数据了，直接可能的异常反而可能更好
        FFmpegFrameGrabber grabber = fFmpegFrameGrabberCache.getGrabber();
        String rtspUrl = fFmpegFrameGrabberCache.getRtspPath();
        boolean isStart = fFmpegFrameGrabberCache.getIsStart();
        String linkId = fFmpegFrameGrabberCache.getLinkId();
        if (grabber == null) {
            log.info("【" + linkId + "】重试连接rtsp: " + rtspUrl + ",开始创建grabber");
            grabber = createGrabber(linkId, rtspUrl);
            if (grabber != null) {
                log.info("【" + linkId + "】创建" + rtspUrl + ": grabber成功");
            } else {
                log.warn("【" + linkId + "】创建" + rtspUrl + ": grabber失败");
            }
        }
        try {
            if (grabber != null && !isStart) {
                grabber.start();
                fFmpegFrameGrabberCache.setIsStart(true);
                log.info("【" + linkId + "】启动" + rtspUrl + ": grabber成功");
            }
            if (grabber != null) {
                Frame frame = grabber.grabImage();
                if (null == frame) {
                    return null;
                }
                BufferedImage bufferedImage = java2DFrameConverter.getBufferedImage(frame);
                byte[] bytes = imageToBytes(bufferedImage, "jpg");
                return new SendRstpInfo()
                        .setLinkId(fFmpegFrameGrabberCache.getLinkId())
                        .setBase64(Base64.encode(bytes));
            }
        } catch (FrameGrabber.Exception | RuntimeException e) {
            log.error("【" + linkId + "】因为异常，grabber关闭，rtsp连接断开，尝试重新连接: " + rtspUrl);
            log.error("exception : ", e);
            if (grabber != null) {
                try {
                    grabber.stop();
                } catch (FrameGrabber.Exception ex) {
                    log.error("grabber stop exception: ", ex);
                } finally {
                    fFmpegFrameGrabberCache.setIsStart(false);
                    fFmpegFrameGrabberCache.setGrabber(null);
                }
            }
            // 休眠3秒后再次尝试重新连接
            try {
                Thread.sleep(3000);
            } catch (InterruptedException ex) {
                log.error("Thread sleep exception: ", ex);
            }
            return null;
        }
        return null;
    }

    public void sendRtspInfo() {
        log.info("启动推流线程服务成功(链路)：" + linkId);
        while (true) {
            try {
                // 休眠的作用可以降低cpu消耗
                Thread.sleep(1);
            } catch (InterruptedException e) {
                log.error("Thread sleep exception: ", e);
            }
            try {
                LinkedBlockingDeque<SendRstpInfo> linkedBlockingDeque = MediaConstant.linkedBlockingDequeConcurrentHashMap.get(linkId);
                SendRstpInfo sendRstpInfo = null;
                if (linkedBlockingDeque != null) {
                    sendRstpInfo = linkedBlockingDeque.poll(50, TimeUnit.MILLISECONDS);
                }
                if (sendRstpInfo == null) {
                    continue;
                }
                //使用websocket发送视频帧数据
                WebSocketServer.sendAllByObject(sendRstpInfo, linkId);
            } catch (InterruptedException | RuntimeException e) {
                log.error("本轮解析视频数据帧集合数据从队列中获取队列失败。。。");
                log.error("linkedBlockingDeque poll exception: ", e);
            }
        }
    }

    /**
     * 图片转字节数组
     *
     * @param bImage 图片数据
     * @param format 格式
     * @return 图片字节码
     */
    private byte[] imageToBytes(BufferedImage bImage, String format) {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        try {
            ImageIO.write(bImage, format, out);
        } catch (IOException e) {
            log.error("bufferImage 转 byte 数组异常");
            log.error("bufferImage transfer byte[] exception: ", e);
            return null;
        }
        return out.toByteArray();
    }

}
