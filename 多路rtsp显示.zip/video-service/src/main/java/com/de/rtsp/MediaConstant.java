package com.de.rtsp;

import cn.hutool.core.collection.CollectionUtil;
import com.de.entity.SendRstpInfo;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;
import org.bytedeco.javacv.FFmpegFrameGrabber;

import java.util.Collection;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingDeque;

/**
 * * @projectName videoservice
 * * @title MadiaConstant
 * * @package com.de.rtsp
 * * @description  解析rtsp需要用到的一些常量
 * * @author IT_CREAT     
 * * @date  2020 2020/8/9/009 15:59  
 * * @version
 */
public class MediaConstant {
    /**
     * 针对每条链路，阻塞队列，用于读法分离
     * key: linkId ,value : 待发送队列数据
     */
    public static ConcurrentHashMap<String, LinkedBlockingDeque<SendRstpInfo>> linkedBlockingDequeConcurrentHashMap = new ConcurrentHashMap();

    /**
     * 存放针对不同websoket的FFmpegFrameGrabberCache
     * key: linkId ,value : FFmpegFrameGrabberCache对象，也就是每个链路的对象
     */
    public static ConcurrentHashMap<String, FFmpegFrameGrabberCache> fFmpegFrameGrabberCaches = new ConcurrentHashMap();

    /**
     * 每条链路对应的FFmpegFrameGrabberCache
     */
    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    @Accessors(chain = true)
    public static class FFmpegFrameGrabberCache {
        // grabber 处理流对象
        private FFmpegFrameGrabber grabber;

        // 是否启动
        private Boolean isStart = false;

        // rtsp地址
        private String rtspPath;

        // 链路id
        private String linkId;
    }

    /**
     * 获取已经已经添加了的链路对应的FFmpegFrameGrabberCache对象
     *
     * @param linkId 链路id
     * @return FFmpegFrameGrabberCache
     */
    public static FFmpegFrameGrabberCache getFFmpegFrameGrabberCache(String linkId) {
        if (fFmpegFrameGrabberCaches.containsKey(linkId)) {
            return fFmpegFrameGrabberCaches.get(linkId);
        }
        return null;
    }

    /**
     * 是否含有相同的SameFFmpegFrameGrabberCache对象
     *
     * @param linkId   链路id
     * @param rtspPath rtsp地址
     * @return boolean
     */
    public static boolean isHaveSameFFmpegFrameGrabberCache(String linkId, String rtspPath) {
        if (fFmpegFrameGrabberCaches.containsKey(linkId)) {
            FFmpegFrameGrabberCache fFmpegFrameGrabberCache = fFmpegFrameGrabberCaches.get(linkId);
            if (linkId.equals(fFmpegFrameGrabberCache.getLinkId()) && rtspPath.equals(fFmpegFrameGrabberCache.getRtspPath())) {
                return true;
            }
        }
        return false;
    }

    /**
     * 在所有的FFmpegFrameGrabberCache中是否已经含有了rtspPath
     *
     * @param rtspPath rtspPath
     * @return boolean
     */
    public static boolean isHaveSamertspPath(String rtspPath) {
        Collection<FFmpegFrameGrabberCache> values = fFmpegFrameGrabberCaches.values();
        if (CollectionUtil.isNotEmpty(values)) {
            for (FFmpegFrameGrabberCache fFmpegFrameGrabberCache : values) {
                if (rtspPath.equals(fFmpegFrameGrabberCache.getRtspPath())) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * 通过rtspPath地址获取链路地址
     * @param rtspPath rtspPath
     * @return linkId 链路地址
     */
    public static String getLinkId(String rtspPath) {
        Collection<FFmpegFrameGrabberCache> values = fFmpegFrameGrabberCaches.values();
        if (CollectionUtil.isNotEmpty(values)) {
            for (FFmpegFrameGrabberCache fFmpegFrameGrabberCache : values) {
                if (rtspPath.equals(fFmpegFrameGrabberCache.getRtspPath())) {
                    return fFmpegFrameGrabberCache.getLinkId();
                }
            }
        }
        return null;
    }
}
