package com.de.controller;

import com.de.entity.AjaxResult;
import com.de.rtsp.MediaConstant;
import com.de.rtsp.MediaStart;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.bytedeco.javacv.FrameGrabber;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * * @projectName videoservice
 * * @title IndexController
 * * @package com.de.controller
 * * @description  首页
 * * @author IT_CREAT     
 * * @date  2020 2020/5/17/017 5:15  
 * * @version c1.0.0
 */
@Controller
@Slf4j
public class IndexController {

    @GetMapping("/")
    public String indexView() {
        return "index";
    }

    @PostMapping("/addAndUpdateRtsp")
    @ResponseBody
    public AjaxResult addAndUpdateRtsp(String linkId, String rtspPath) {
        if (StringUtils.isBlank(linkId) || StringUtils.isBlank(rtspPath)) {
            return AjaxResult.error("输入参数存在有误，linkId 或者 rtspPath为空");
        }
        boolean haveSameFFmpegFrameGrabberCache = MediaConstant.isHaveSameFFmpegFrameGrabberCache(linkId.trim(), rtspPath.trim());
        boolean haveSamertspPath = MediaConstant.isHaveSamertspPath(rtspPath.trim());
        String linkIdCopy = MediaConstant.getLinkId(rtspPath.trim());
        // 当要修改的rtspPath地址不是在存在准备修改的linkId上，而是存在其他linkId上，则不允许修改，这样做是避免同时解析两个相同的rtsp地址导致流错乱
        if(!haveSameFFmpegFrameGrabberCache && haveSamertspPath){
            return AjaxResult.error("输入参数存在有误，要更改的rtspPath地址已经存在于其他链路上，不允许在此链路修改,请移步先将链路：["+linkIdCopy+"]的rtsp地址更改后再来更改");
        }
        MediaConstant.FFmpegFrameGrabberCache fFmpegFrameGrabberCache1 = MediaConstant.getFFmpegFrameGrabberCache(linkId.trim());
        String message = "";
        // 如果为空，则说明没有添加过该链路的FFmpegFrameGrabberCache
        if (fFmpegFrameGrabberCache1 == null) {
            MediaConstant.FFmpegFrameGrabberCache fFmpegFrameGrabberCache =
                    new MediaConstant.FFmpegFrameGrabberCache()
                            .setLinkId(linkId.trim())
                            .setRtspPath(rtspPath.trim());
            MediaConstant.fFmpegFrameGrabberCaches.put(linkId.trim(), fFmpegFrameGrabberCache);
            message = "添加" + linkId + "：rtsp地址成功";
        } else { // 如果不为空，则要将该链路对应的数据更改为初始化状态，添加新的信息
            try {
                fFmpegFrameGrabberCache1.getGrabber().stop();
            } catch (FrameGrabber.Exception e) {
                log.error("FrameGrabber stop exception: ", e);
            }
            fFmpegFrameGrabberCache1.setRtspPath(rtspPath)
                    .setLinkId(linkId)
                    .setGrabber(null)
                    .setIsStart(false);
            message = "修改" + linkId + "：rtsp地址成功";
        }
        //启动当前链路线程
        MediaStart.addLinkThreadPool(linkId.trim());
        return AjaxResult.success(message);
    }
}
