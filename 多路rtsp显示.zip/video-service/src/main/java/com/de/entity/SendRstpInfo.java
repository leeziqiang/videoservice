package com.de.entity;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.experimental.Accessors;

/**
 * * @projectName videoservice
 * * @title SendRstpInfo
 * * @package com.de.entity
 * * @description  推送到前端的rtsp数据
 * * @author IT_CREAT     
 * * @date  2020 2020/8/9/009 15:21  
 * * @version
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@Accessors(chain = true)
public class SendRstpInfo {
    private String linkId;
    private String base64;
}
