package com.de.entity;

import com.alibaba.fastjson.JSON;

import javax.websocket.EncodeException;
import javax.websocket.Encoder;
import javax.websocket.EndpointConfig;

/**
 *  
 *  * @projectName videoservice
 *  * @title     ImageEncoder   
 *  * @package    com.de.entity  
 *  * @description    websocket 传输对象转码 
 *  * @author IT_CREAT     
 *  * @date  2020 2020/4/18 0018 下午 22:53  
 *  * @version V1.0.0 
 *  
 */
public class ImageEncoder implements Encoder.Text<SendRstpInfo> {

    @Override
    public String encode(SendRstpInfo sendRstpInfos) throws EncodeException {
        if (sendRstpInfos != null) {
            return JSON.toJSONString(new AjaxResult(AjaxResult.Type.SUCCESS_IMG_BYTE, "获取视频帧成功", sendRstpInfos));
        }
        return JSON.toJSONString(AjaxResult.error("获取视频帧失败"));
    }

    @Override
    public void init(EndpointConfig endpointConfig) {

    }

    @Override
    public void destroy() {

    }
}
