# videoservice
视频播放测试服务（spring boot+javacv+websocket）  
spring boot+opencv+websocket:https://www.freesion.com/article/2770277090/  
Web下无插件播放rtsp视频流的方案总结_网络_经验之外:https://blog.csdn.net/ajrm0925/article/details/91879551?depth_1-utm_source=distribute.pc_relevant.none-task-blog-BlogCommendFromBaidu-2&utm_source=distribute.pc_relevant.none-task-blog-BlogCommendFromBaidu-2  
FFmpeg转封装rtsp到rtmp（无需转码，低资源消耗）_Java_banmajio的博客-CSDN博客:https://blog.csdn.net/weixin_40777510/article/details/103764198?depth_1-utm_source=distribute.pc_relevant.none-task-blog-BlogCommendFromBaidu-7&utm_source=distribute.pc_relevant.none-task-blog-BlogCommendFromBaidu-7  
easyCV/pom.xml at master · eguid/easyCV · GitHub:https://github.com/eguid/easyCV/blob/master/pom.xml  
javacv rtsp rtmp_Java：https://blog.csdn.net/zb313982521/article/details/88110368  
JAVA中通过JavaCV实现跨平台视频/图像处理-调用摄像头：https://blog.csdn.net/weixin_33881041/article/details/85992437  
javacv 通过rtsp 获取视频流 设置帧率：https://www.cnblogs.com/svenwu/p/9663038.html  
javaCV开发详解之8：转封装在rtsp转rtmp流中的应用（无须转码，更低的资源消耗）：https://www.cnblogs.com/eguid/p/10195557.html  
RTSP实例解析：https://www.cnblogs.com/qq78292959/archive/2010/08/12/2077039.html  
JAVACV集成海康摄像头RTSP流时出现的丢包与无法解析的问题：https://bbs.csdn.net/topics/392237412?page=1java使用opencv拉取rtsp流：https://blog.csdn.net/sinat_21184471/article/details/93978622  
WebSocket插件：https://www.bbsmax.com/A/RnJW3xRRJq/sockjs+stomp的websocket插件  
sockjs+stomp的websocket插件：https://www.bbsmax.com/A/pRdBPLN9Jn/  
SpringBoot使用Websocket：https://blog.csdn.net/weixin_43835717/article/details/94066791  
SpringBoot2.0集成WebSocket，实现后台向前端推送信息：https://blog.csdn.net/moshowgame/article/details/80275084  
【Websoket】实时推送图像数据，前端实时显示：https://blog.csdn.net/qq_20038925/article/details/70919307  
WebSocket传输图片：https://www.cnblogs.com/jzblogs/p/5613988.html  
JavaScript进行WebSocket字节流通讯示例：https://blog.coloc.cc/2018/11/javascriptwebsocket.html  
JavaScript进行WebSocket字节流通讯示例 ：https://www.cnblogs.com/coloc/p/8127268.html  
spring boot 使用WebSocket与前端进行byte字节数组交互：https://blog.csdn.net/m0_37992075/article/details/83587624  
spring boot集成javacv + websocket实现实时视频推流回放（延时1-2秒）：https://blog.csdn.net/qq_23945685/article/details/104074262   
